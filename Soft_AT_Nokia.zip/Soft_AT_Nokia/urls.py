# Soft_AT_Nokia/urls.py

from django.urls import path
# from .views import process_xml_view
from .views import upload_and_compare_xml_files


urlpatterns = [
    path('process-xml/',upload_and_compare_xml_files ),
    #  path('upload/',Physical_At_Report_Upload),
]
