import os
import csv
from django.conf import settings
from rest_framework.decorators import api_view, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status
import xml.etree.ElementTree as ET

from .models import ExpectedParameter

ns = {'ns': 'http://www.example.com/schema'}

def extract_site_id(dist_name):
    try:
        parts = dist_name.split('/')
        for part in parts:
            if part.startswith("MRBTS-"):
                return part.split('-')[1]
    except Exception:
        return None
    return None

def normalize_path(path):
    return path.strip().lower()

@api_view(['POST'])
@parser_classes([MultiPartParser, FormParser])
def upload_and_compare_xml_files(request):
    files = request.FILES.getlist('files')
    circle_name = request.data.get('circle_name', 'default_circle')  # agar client se circle aata ho
    
    if not files:
        return Response({"error": "No files uploaded"}, status=status.HTTP_400_BAD_REQUEST)

    expected_params = ExpectedParameter.objects.all()
    expected_values = {}
    for param in expected_params:
        norm_path = normalize_path(param.path)
        if norm_path not in expected_values:
            expected_values[norm_path] = {}
        expected_values[norm_path][param.parameter_name.lower()] = param.expected_value

    results = []

    for xml_file in files:
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
        except ET.ParseError:
            results.append({
                "file": xml_file.name,
                "error": "Malformed XML",
                "status": "Failed"
            })
            continue

        for mo in root.findall('.//ns:managedObject', ns):
            dist_name = mo.attrib.get('distName', '')
            site_id = extract_site_id(dist_name)
            norm_path = normalize_path(dist_name)

            if not site_id:
                continue

            for p in mo.findall('ns:p', ns):
                param_name = p.attrib.get('name')
                actual_val = p.text.strip() if p.text else ''
                actual_param_lower = param_name.lower()

                expected_param_map = expected_values.get(norm_path, {})
                if actual_param_lower in expected_param_map and f"MRBTS-{site_id}" in dist_name:
                    expected_val = expected_param_map[actual_param_lower]

                    clean_actual = actual_val.lower().replace(" ", "").replace(";", "")
                    clean_expected = expected_val.lower().replace(" ", "").replace(";", "")

                    if param_name.lower() == 'actlbpowersaving':
                        if actual_val.lower() == 'true':
                            status_val = "OK (Relocation)"
                        elif actual_val.lower() == 'false':
                            status_val = "OK (ULS)"
                        else:
                            status_val = "Not OK"
                    else:
                        status_val = "OK" if clean_actual == clean_expected else "Not OK"

                    results.append({
                        "file": xml_file.name,
                        "site_id": site_id,
                        "mo_path": dist_name,
                        "parameter": param_name,
                        "actual_value": actual_val,
                        "expected_value": expected_val,
                        "status": status_val,
                    })

    # --- CSV Report Generation ---
    report_folder = os.path.join(settings.MEDIA_ROOT, 'reports')
    os.makedirs(report_folder, exist_ok=True)
    report_filename = f"report_{circle_name}.csv"
    report_filepath = os.path.join(report_folder, report_filename)

    with open(report_filepath, 'w', newline='') as csvfile:
        fieldnames = ['file', 'site_id', 'mo_path', 'parameter', 'actual_value', 'expected_value', 'status']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        for row in results:
            # agar 'error' key ho to skip karo (malformed files)
            if 'error' in row:
                continue
            writer.writerow({
                'file': row['file'],
                'site_id': row['site_id'],
                'mo_path': row['mo_path'],
                'parameter': row['parameter'],
                'actual_value': row['actual_value'],
                'expected_value': row['expected_value'],
                'status': row['status'],
            })

    # --- Prepare download link ---
    download_link = request.build_absolute_uri(settings.MEDIA_URL + 'reports/' + report_filename)

    return Response({
        "message": f"Report generated successfully for circle: {circle_name}",
        "download_link": download_link,
        "status": True
    }, status=status.HTTP_200_OK)
