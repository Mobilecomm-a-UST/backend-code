from django.db import models

class ExpectedParameter(models.Model):
    path = models.CharField(max_length=500)
    parameter_name = models.CharField(max_length=200)
    expected_value = models.CharField(max_length=500)

    # Normalize path before saving
    def save(self, *args, **kwargs):
        if self.path:
            self.path = self.path.strip().lower()
        if self.parameter_name:
            self.parameter_name = self.parameter_name.strip().lower()
        if self.expected_value:
            self.expected_value = self.expected_value.strip()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.path} - {self.parameter_name}: {self.expected_value}"
